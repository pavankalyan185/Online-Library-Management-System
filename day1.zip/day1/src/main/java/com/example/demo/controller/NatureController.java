package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.Nature;
import com.example.demo.service.NatureService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/nature")
@CrossOrigin("*") // Allow frontend access
public class NatureController {

    @Autowired
    private NatureService natureService;

    // Get all nature books
    @GetMapping
    public List<Nature> getAllNatureBooks() {
        return natureService.getAllNatureBooks();
    }

    // Get nature book by ID
    @GetMapping("/{id}")
    public Optional<Nature> getNatureById(@PathVariable Long id) {
        return natureService.getNatureById(id);
    }

    // Add a new nature book
    @PostMapping
    public Nature addNature(@RequestBody Nature nature) {
        return natureService.addNature(nature);
    }

    // Update a nature book
    @PutMapping("/{id}")
    public Nature updateNature(@PathVariable Long id, @RequestBody Nature natureDetails) {
        return natureService.updateNature(id, natureDetails);
    }

    // Delete a nature book
    @DeleteMapping("/{id}")
    public void deleteNature(@PathVariable Long id) {
        natureService.deleteNature(id);
    }
}

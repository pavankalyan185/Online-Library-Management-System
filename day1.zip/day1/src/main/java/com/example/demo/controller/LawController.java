package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Law;
import com.example.demo.service.LawService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/law")
@CrossOrigin("*") // Allow frontend access
public class LawController {

    @Autowired
    private LawService lawService;

    // Get all law books
    @GetMapping
    public List<Law> getAllLawBooks() {
        return lawService.getAllLawBooks();
    }

    // Get law book by ID
    @GetMapping("/{id}")
    public Optional<Law> getLawById(@PathVariable Long id) {
        return lawService.getLawById(id);
    }

    // Add a new law book
    @PostMapping
    public Law addLaw(@RequestBody Law law) {
        return lawService.addLaw(law);
    }

    // Update a law book
    @PutMapping("/{id}")
    public Law updateLaw(@PathVariable Long id, @RequestBody Law lawDetails) {
        return lawService.updateLaw(id, lawDetails);
    }

    // Delete a law book
    @DeleteMapping("/{id}")
    public void deleteLaw(@PathVariable Long id) {
        lawService.deleteLaw(id);
    }
}

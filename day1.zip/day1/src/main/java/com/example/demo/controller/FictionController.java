package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.Fiction;
import com.example.demo.service.FictionService;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/fiction")
@CrossOrigin("*") // Allow frontend access
public class FictionController {



    @Autowired
    private FictionService fictionService;

    @GetMapping
    public List<Fiction> getAllFiction() {
        return fictionService.getAllFiction();
    }

    @GetMapping("/{id}")
    public Optional<Fiction> getFictionById(@PathVariable Long id) {
        return fictionService.getFictionById(id);
    }

    @PostMapping
    public Fiction addFiction(@RequestBody Fiction fiction) {
        return fictionService.saveFiction(fiction);
    }

    @PutMapping("/{id}")
    public Fiction updateFiction(@PathVariable Long id, @RequestBody Fiction fictionDetails) {
        return fictionService.updateFiction(id, fictionDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteFiction(@PathVariable Long id) {
        fictionService.deleteFiction(id);
    }
}


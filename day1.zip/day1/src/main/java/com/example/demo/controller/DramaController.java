package com.example.demo.controller;


import com.example.demo.entity.Drama;
import com.example.demo.service.DramaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/drama")
@CrossOrigin(origins = "http://localhost:3000")
public class DramaController {

    



    @Autowired
    private DramaService dramaService;

    @GetMapping
    public List<Drama> getAllDramas() {
        return dramaService.getAllDramas();
    }

    @GetMapping("/{id}")
    public Optional<Drama> getDramaById(@PathVariable Long id) {
        return dramaService.getDramaById(id);
    }

    @PostMapping
    public Drama addDrama(@RequestBody Drama drama) {
        return dramaService.saveDrama(drama);
    }

    @PutMapping("/{id}")
    public Drama updateDrama(@PathVariable Long id, @RequestBody Drama dramaDetails) {
        return dramaService.updateDrama(id, dramaDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteDrama(@PathVariable Long id) {
        dramaService.deleteDrama(id);
    }}


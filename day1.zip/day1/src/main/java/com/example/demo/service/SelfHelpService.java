package com.example.demo.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.SelfHelp;
import com.example.demo.repo.SelfHelpRepository;

import java.util.List;
import java.util.Optional;

@Service
public class SelfHelpService {

    @Autowired
    private SelfHelpRepository selfHelpRepository;

    // Get all Self-Help books
    public List<SelfHelp> getAllSelfHelpBooks() {
        return selfHelpRepository.findAll();
    }

    // Get a Self-Help book by ID
    public Optional<SelfHelp> getSelfHelpById(Long id) {
        return selfHelpRepository.findById(id);
    }

    // Add a new Self-Help book
    public SelfHelp addSelfHelp(SelfHelp selfHelp) {
        return selfHelpRepository.save(selfHelp);
    }

    // Update a Self-Help book
    public SelfHelp updateSelfHelp(Long id, SelfHelp selfHelpDetails) {
        return selfHelpRepository.findById(id).map(selfHelp -> {
            selfHelp.setName(selfHelpDetails.getName());
            selfHelp.setAuthor(selfHelpDetails.getAuthor());
            selfHelp.setDescription(selfHelpDetails.getDescription());
            selfHelp.setPdfUrl(selfHelpDetails.getPdfUrl());
            selfHelp.setYoutubeUrl(selfHelpDetails.getYoutubeUrl());
            selfHelp.setImageUrl(selfHelpDetails.getImageUrl());
            return selfHelpRepository.save(selfHelp);
        }).orElseThrow(() -> new RuntimeException("Self-Help book not found"));
    }

    // Delete a Self-Help book
    public void deleteSelfHelp(Long id) {
        selfHelpRepository.deleteById(id);
    }
}

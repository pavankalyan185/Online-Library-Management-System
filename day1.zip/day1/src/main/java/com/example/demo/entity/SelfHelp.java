package com.example.demo.entity;



import jakarta.persistence.*;

@Entity
@Table(name = "self_help")
public class SelfHelp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String author;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String pdfUrl;
    private String youtubeUrl;
    private String imageUrl;

    // Constructors
    public SelfHelp() {}

    public SelfHelp(String name, String author, String description, String pdfUrl, String youtubeUrl,String imageUrl) {
        this.name = name;
        this.author = author;
        this.description = description;
        this.pdfUrl = pdfUrl;
        this.youtubeUrl = youtubeUrl;
        this.imageUrl = imageUrl;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getPdfUrl() { return pdfUrl; }
    public void setPdfUrl(String pdfUrl) { this.pdfUrl = pdfUrl; }

    public String getYoutubeUrl() { return youtubeUrl; }
    public void setYoutubeUrl(String youtubeUrl) { this.youtubeUrl = youtubeUrl; }
    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}

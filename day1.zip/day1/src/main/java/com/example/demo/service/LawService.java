package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Law;
import com.example.demo.repo.LawRepository;

import java.util.List;
import java.util.Optional;

@Service
public class LawService {

	@Autowired
    private LawRepository lawRepository;

    // Get all law books
    public List<Law> getAllLawBooks() {
        return lawRepository.findAll();
    }

    // Get a law book by ID
    public Optional<Law> getLawById(Long id) {
        return lawRepository.findById(id);
    }

    // Add a new law book
    public Law addLaw(Law law) {
        return lawRepository.save(law);
    }

    // Update a law book
    public Law updateLaw(Long id, Law lawDetails) {
        return lawRepository.findById(id).map(law -> {
            law.setName(lawDetails.getName());
            law.setAuthor(lawDetails.getAuthor());
            law.setDescription(lawDetails.getDescription());
            law.setPdfUrl(lawDetails.getPdfUrl());
            law.setYoutubeUrl(lawDetails.getYoutubeUrl());
            law.setImageUrl(lawDetails.getImageUrl());
            return lawRepository.save(law);
        }).orElseThrow(() -> new RuntimeException("Law book not found"));
    }

    // Delete a law book
    public void deleteLaw(Long id) {
        lawRepository.deleteById(id);
    }
}
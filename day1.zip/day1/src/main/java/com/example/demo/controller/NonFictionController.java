package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.NonFiction;
import com.example.demo.service.NonFictionService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/nonfiction")
@CrossOrigin("*") // Allow frontend access
public class NonFictionController {

    @Autowired
    private NonFictionService nonFictionService;

    // Get all Non-Fiction books
    @GetMapping
    public List<NonFiction> getAllNonFictionBooks() {
        return nonFictionService.getAllNonFictionBooks();
    }

    // Get Non-Fiction book by ID
    @GetMapping("/{id}")
    public Optional<NonFiction> getNonFictionById(@PathVariable Long id) {
        return nonFictionService.getNonFictionById(id);
    }

    // Add a new Non-Fiction book
    @PostMapping
    public NonFiction addNonFiction(@RequestBody NonFiction nonFiction) {
        return nonFictionService.addNonFiction(nonFiction);
    }

    // Update a Non-Fiction book
    @PutMapping("/{id}")
    public NonFiction updateNonFiction(@PathVariable Long id, @RequestBody NonFiction nonFictionDetails) {
        return nonFictionService.updateNonFiction(id, nonFictionDetails);
    }

    // Delete a Non-Fiction book
    @DeleteMapping("/{id}")
    public void deleteNonFiction(@PathVariable Long id) {
        nonFictionService.deleteNonFiction(id);
    }
}

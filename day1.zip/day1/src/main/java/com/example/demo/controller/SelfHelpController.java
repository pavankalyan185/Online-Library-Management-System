package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.SelfHelp;
import com.example.demo.service.SelfHelpService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/selfhelp")
@CrossOrigin("*") // Allow frontend access
public class SelfHelpController {

    @Autowired
    private SelfHelpService selfHelpService;

    // Get all Self-Help books
    @GetMapping
    public List<SelfHelp> getAllSelfHelpBooks() {
        return selfHelpService.getAllSelfHelpBooks();
    }

    // Get Self-Help book by ID
    @GetMapping("/{id}")
    public Optional<SelfHelp> getSelfHelpById(@PathVariable Long id) {
        return selfHelpService.getSelfHelpById(id);
    }

    // Add a new Self-Help book
    @PostMapping
    public SelfHelp addSelfHelp(@RequestBody SelfHelp selfHelp) {
        return selfHelpService.addSelfHelp(selfHelp);
    }

    // Update a Self-Help book
    @PutMapping("/{id}")
    public SelfHelp updateSelfHelp(@PathVariable Long id, @RequestBody SelfHelp selfHelpDetails) {
        return selfHelpService.updateSelfHelp(id, selfHelpDetails);
    }

    // Delete a Self-Help book
    @DeleteMapping("/{id}")
    public void deleteSelfHelp(@PathVariable Long id) {
        selfHelpService.deleteSelfHelp(id);
    }
}

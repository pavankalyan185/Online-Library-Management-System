package com.example.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Drama;
import com.example.demo.repo.DramaRepository;
import java.util.List;
import java.util.Optional;

@Service
public class DramaService {

    

   

    

    




    @Autowired
    private DramaRepository dramaRepository;

    public List<Drama> getAllDramas() {
        return dramaRepository.findAll();
    }

    public Optional<Drama> getDramaById(Long id) {
        return dramaRepository.findById(id);
    }

    public Drama saveDrama(Drama drama) {
        return dramaRepository.save(drama);
    }

    public Drama updateDrama(Long id, Drama dramaDetails) {
        return dramaRepository.findById(id).map(drama -> {
            drama.setName(dramaDetails.getName());
            drama.setAuthor(dramaDetails.getAuthor());
            drama.setDescription(dramaDetails.getDescription());
            drama.setPdfUrl(dramaDetails.getPdfUrl());
            drama.setYoutubeUrl(dramaDetails.getYoutubeUrl());
            drama.setImageUrl(dramaDetails.getImageUrl()); // Save image URL
            return dramaRepository.save(drama);
        }).orElseThrow(() -> new RuntimeException("Drama not found"));
    }

    public void deleteDrama(Long id) {
        dramaRepository.deleteById(id);
    }
}

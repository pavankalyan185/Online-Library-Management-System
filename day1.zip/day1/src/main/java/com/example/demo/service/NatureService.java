package com.example.demo.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Nature;
import com.example.demo.repo.NatureRepository;

import java.util.List;
import java.util.Optional;

@Service
public class NatureService {

    @Autowired
    private NatureRepository natureRepository;

    // Get all nature books
    public List<Nature> getAllNatureBooks() {
        return natureRepository.findAll();
    }

    // Get a nature book by ID
    public Optional<Nature> getNatureById(Long id) {
        return natureRepository.findById(id);
    }

    // Add a new nature book
    public Nature addNature(Nature nature) {
        return natureRepository.save(nature);
    }

    // Update a nature book
    public Nature updateNature(Long id, Nature natureDetails) {
        return natureRepository.findById(id).map(nature -> {
            nature.setName(natureDetails.getName());
            nature.setAuthor(natureDetails.getAuthor());
            nature.setDescription(natureDetails.getDescription());
            nature.setPdfUrl(natureDetails.getPdfUrl());
            nature.setYoutubeUrl(natureDetails.getYoutubeUrl());
            nature.setImageUrl(natureDetails.getImageUrl());
            return natureRepository.save(nature);
        }).orElseThrow(() -> new RuntimeException("Nature book not found"));
    }

    // Delete a nature book
    public void deleteNature(Long id) {
        natureRepository.deleteById(id);
    }
}

package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Fiction;
import com.example.demo.repo.FictionRepository;

import java.util.List;
import java.util.Optional;

@Service
public class FictionService {

        @Autowired
    private FictionRepository fictionRepository;

    public List<Fiction> getAllFiction() {
        return fictionRepository.findAll();
    }

    public Optional<Fiction> getFictionById(Long id) {
        return fictionRepository.findById(id);
    }

    public Fiction saveFiction(Fiction fiction) {
        return fictionRepository.save(fiction);
    }

    public Fiction updateFiction(Long id, Fiction fictionDetails) {
        return fictionRepository.findById(id).map(fiction -> {
            fiction.setName(fictionDetails.getName());
            fiction.setAuthor(fictionDetails.getAuthor());
            fiction.setDescription(fictionDetails.getDescription());
            fiction.setPdfUrl(fictionDetails.getPdfUrl());
            fiction.setYoutubeUrl(fictionDetails.getYoutubeUrl());
            fiction.setImageUrl(fictionDetails.getImageUrl()); // Save image URL
            return fictionRepository.save(fiction);
        }).orElseThrow(() -> new RuntimeException("Fiction not found"));
    }

    public void deleteFiction(Long id) {
        fictionRepository.deleteById(id);
    }
}


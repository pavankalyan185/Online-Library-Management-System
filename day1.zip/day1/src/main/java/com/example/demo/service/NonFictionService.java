package com.example.demo.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.NonFiction;
import com.example.demo.repo.NonFictionRepository;

import java.util.List;
import java.util.Optional;

@Service
public class NonFictionService {

    @Autowired
    private NonFictionRepository nonFictionRepository;

    // Get all Non-Fiction books
    public List<NonFiction> getAllNonFictionBooks() {
        return nonFictionRepository.findAll();
    }

    // Get a Non-Fiction book by ID
    public Optional<NonFiction> getNonFictionById(Long id) {
        return nonFictionRepository.findById(id);
    }

    // Add a new Non-Fiction book
    public NonFiction addNonFiction(NonFiction nonFiction) {
        return nonFictionRepository.save(nonFiction);
    }

    // Update a Non-Fiction book
    public NonFiction updateNonFiction(Long id, NonFiction nonFictionDetails) {
        return nonFictionRepository.findById(id).map(nonFiction -> {
            nonFiction.setName(nonFictionDetails.getName());
            nonFiction.setAuthor(nonFictionDetails.getAuthor());
            nonFiction.setDescription(nonFictionDetails.getDescription());
            nonFiction.setPdfUrl(nonFictionDetails.getPdfUrl());
            nonFiction.setYoutubeUrl(nonFictionDetails.getYoutubeUrl());
            nonFiction.setImageUrl(nonFictionDetails.getImageUrl());
            return nonFictionRepository.save(nonFiction);
        }).orElseThrow(() -> new RuntimeException("Non-Fiction book not found"));
    }

    // Delete a Non-Fiction book
    public void deleteNonFiction(Long id) {
        nonFictionRepository.deleteById(id);
    }
}

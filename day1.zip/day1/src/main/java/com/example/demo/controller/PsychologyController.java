package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.Psychology;
import com.example.demo.service.PsychologyService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/psychology")
@CrossOrigin("*") // Allow frontend access
public class PsychologyController {

    @Autowired
    private PsychologyService psychologyService;

    // Get all Psychology books
    @GetMapping
    public List<Psychology> getAllPsychologyBooks() {
        return psychologyService.getAllPsychologyBooks();
    }

    // Get Psychology book by ID
    @GetMapping("/{id}")
    public Optional<Psychology> getPsychologyById(@PathVariable Long id) {
        return psychologyService.getPsychologyById(id);
    }

    // Add a new Psychology book
    @PostMapping
    public Psychology addPsychology(@RequestBody Psychology psychology) {
        return psychologyService.addPsychology(psychology);
    }

    // Update a Psychology book
    @PutMapping("/{id}")
    public Psychology updatePsychology(@PathVariable Long id, @RequestBody Psychology psychologyDetails) {
        return psychologyService.updatePsychology(id, psychologyDetails);
    }

    // Delete a Psychology book
    @DeleteMapping("/{id}")
    public void deletePsychology(@PathVariable Long id) {
        psychologyService.deletePsychology(id);
    }
}
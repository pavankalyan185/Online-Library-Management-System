package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.History;
import com.example.demo.service.HistoryService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/history")
@CrossOrigin("*") // Allow frontend access
public class HistoryController {

    @Autowired
    private HistoryService historyService;

    // Get all history books
    @GetMapping
    public List<History> getAllHistoryBooks() {
        return historyService.getAllHistoryBooks();
    }

    // Get history book by ID
    @GetMapping("/{id}")
    public Optional<History> getHistoryById(@PathVariable Long id) {
        return historyService.getHistoryById(id);
    }

    // Add a new history book
    @PostMapping
    public History addHistory(@RequestBody History history) {
        return historyService.addHistory(history);
    }

    // Update a history book
    @PutMapping("/{id}")
    public History updateHistory(@PathVariable Long id, @RequestBody History historyDetails) {
        return historyService.updateHistory(id, historyDetails);
    }

    // Delete a history book
    @DeleteMapping("/{id}")
    public void deleteHistory(@PathVariable Long id) {
        historyService.deleteHistory(id);
    }
}

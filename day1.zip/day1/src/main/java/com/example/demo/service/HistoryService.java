package com.example.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.History;
import com.example.demo.repo.HistoryRepository;

import java.util.List;
import java.util.Optional;

@Service
public class HistoryService {

	@Autowired
    private HistoryRepository historyRepository;

    // Get all history books
    public List<History> getAllHistoryBooks() {
        return historyRepository.findAll();
    }

    // Get a history book by ID
    public Optional<History> getHistoryById(Long id) {
        return historyRepository.findById(id);
    }

    // Add a new history book
    public History addHistory(History history) {
        return historyRepository.save(history);
    }

    // Update a history book
    public History updateHistory(Long id, History historyDetails) {
        return historyRepository.findById(id).map(history -> {
            history.setName(historyDetails.getName());
            history.setAuthor(historyDetails.getAuthor());
            history.setDescription(historyDetails.getDescription());
            history.setPdfUrl(historyDetails.getPdfUrl());
            history.setYoutubeUrl(historyDetails.getYoutubeUrl());
            history.setImageUrl(historyDetails.getImageUrl());
            return historyRepository.save(history);
        }).orElseThrow(() -> new RuntimeException("History book not found"));
    }

    // Delete a history book
    public void deleteHistory(Long id) {
        historyRepository.deleteById(id);
    }
}

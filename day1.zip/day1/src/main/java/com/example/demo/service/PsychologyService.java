package com.example.demo.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Psychology;
import com.example.demo.repo.PsychologyRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PsychologyService {

    @Autowired
    private PsychologyRepository psychologyRepository;

    // Get all Psychology books
    public List<Psychology> getAllPsychologyBooks() {
        return psychologyRepository.findAll();
    }

    // Get a Psychology book by ID
    public Optional<Psychology> getPsychologyById(Long id) {
        return psychologyRepository.findById(id);
    }

    // Add a new Psychology book
    public Psychology addPsychology(Psychology psychology) {
        return psychologyRepository.save(psychology);
    }

    // Update a Psychology book
    public Psychology updatePsychology(Long id, Psychology psychologyDetails) {
        return psychologyRepository.findById(id).map(psychology -> {
            psychology.setName(psychologyDetails.getName());
            psychology.setAuthor(psychologyDetails.getAuthor());
            psychology.setDescription(psychologyDetails.getDescription());
            psychology.setPdfUrl(psychologyDetails.getPdfUrl());
            psychology.setYoutubeUrl(psychologyDetails.getYoutubeUrl());
            psychology.setImageUrl(psychologyDetails.getImageUrl());
            return psychologyRepository.save(psychology);
        }).orElseThrow(() -> new RuntimeException("Psychology book not found"));
    }

    // Delete a Psychology book
    public void deletePsychology(Long id) {
        psychologyRepository.deleteById(id);
    }
}

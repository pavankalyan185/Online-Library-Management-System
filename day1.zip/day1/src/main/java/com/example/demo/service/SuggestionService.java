package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Suggestion;
import com.example.demo.repo.SuggestionRepository;

@Service
public class SuggestionService {
    @Autowired
    private SuggestionRepository repository;

    public Suggestion saveSuggestion(Suggestion suggestion) {
        return repository.save(suggestion);
    }
}

package com.example.demo.entity;



import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "law_books")
public class Law {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    private String author;
    private String description;
    private String pdfUrl;
    private String youtubeUrl;
    @Column(nullable = true) // URL for the history book cover image
    private String imageUrl;
}
